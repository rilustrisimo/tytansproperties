<?php
// @codingStandardsIgnoreFile

class Stripe_BitcoinTransaction extends Stripe_ApiResource
{

}
