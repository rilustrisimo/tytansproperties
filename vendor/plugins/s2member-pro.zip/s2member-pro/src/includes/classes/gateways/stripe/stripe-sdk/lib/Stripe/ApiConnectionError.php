<?php
// @codingStandardsIgnoreFile

class Stripe_ApiConnectionError extends Stripe_Error
{
}
