<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

[s2Member-Pro-Stripe-Form sp="1" ids="0" exp="72" desc="<?php echo esc_attr (_x ("Description and pricing details here.", "s2member-admin", "s2member")); ?>" cc="USD" custom="%%custom%%" ra="0.50" coupon="" accept_coupons="0" default_country_code="US" captcha="0" /]
