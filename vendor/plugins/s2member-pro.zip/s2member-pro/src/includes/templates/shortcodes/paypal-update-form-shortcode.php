<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

[s2Member-Pro-PayPal-Form update="1" desc="<?php echo esc_attr (_x ("Update your billing information.", "s2member-front", "s2member")); ?>" accept="paypal,visa,mastercard,amex,discover,maestro,solo" default_country_code="" captcha="0" /]
