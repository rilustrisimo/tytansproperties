<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit ("Do not access this file directly.");
?>

<a href="#" onclick="s2member_pro_google_wallet_checkout(this, {jwt_attr: '%%jwt_attr%%', success: '%%success%%', failure: '%%failure%%'}); return false;">
 <img src="%%images%%/google-wallet-co.png" style="width:auto; height:auto; border:0;" alt="Google Wallet" />
</a>
