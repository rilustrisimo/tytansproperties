<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit ("Do not access this file directly.");
?>

<a href="https://wallet.google.com/">
 <img src="%%images%%/google-edit-button.png" style="width:auto; height:auto; border:0;" alt="Google Wallet" />
</a>
