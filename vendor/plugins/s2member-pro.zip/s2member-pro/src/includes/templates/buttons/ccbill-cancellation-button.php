<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit ("Do not access this file directly.");
?>

<a href="https://support.ccbill.com/">
 <img src="%%images%%/ccbill-edit-button.png" style="width:auto; height:auto; border:0;" alt="ccBill" />
</a>
