These images exist for backward compatibility with existing s2Member installations.
