## s2Member® Framework

s2Member® Framework ~ membership management for WordPress®.

## BRANCH RENAME: `000000-dev` is now just `dev` ...

See announcement: https://github.com/websharks/s2member/issues/968
