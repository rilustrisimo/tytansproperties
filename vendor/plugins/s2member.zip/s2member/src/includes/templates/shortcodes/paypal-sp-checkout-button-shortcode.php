<?php
// @codingStandardsIgnoreFile
if(!defined('WPINC')) // MUST have WordPress.
	exit("Do not access this file directly.");
?>

[s2Member-PayPal-Button sp="1" ids="0" exp="72" desc="<?php echo esc_attr (_x ("Description and pricing details here.", "s2member-admin", "s2member")); ?>" ps="paypal" lc="" cc="USD" dg="0" ns="1" custom="%%custom%%" ra="0.01" image="default" output="button" /]
