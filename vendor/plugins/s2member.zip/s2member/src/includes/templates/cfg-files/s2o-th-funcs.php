<?php
// @codingStandardsIgnoreFile
if(!defined('_WS_PLUGIN__S2MEMBER_ONLY'))
	exit('Do not access this file directly.');
?>

// s2Member-only mode. Do NOT load theme functions, exclude all themes.
